package application;
	

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.geometry.Pos;



public class Main extends Application {
    private static final Logger logger = Logger.getLogger(Main.class.getName());
    private EmpSql EmpSql = new EmpSql();
    public static final String BLANK = "";

    @Override
    public void start(Stage stage) {
            stage.setTitle("COMP228Final");

            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(12);
            grid.setVgap(12);
            grid.setPadding(new Insets(30, 30, 30, 30));

            Text sceneTitle = new Text("Enter Employee ID");
            grid.add(sceneTitle, 0, 0, 2, 1);

            Label employeeIdLabel = new Label("Employee ID:");
            grid.add(employeeIdLabel, 0, 1);

            TextField employeeIdField = new TextField();
            grid.add(employeeIdField, 1, 1);

            Label employeeNameLabel = new Label("Employee Name:");
            grid.add(employeeNameLabel, 0, 2);

            TextField employeeNameField = new TextField();
            grid.add(employeeNameField, 1, 2);

            Label grossSalaryLabel = new Label("Gross Salary:");
            grid.add(grossSalaryLabel, 0, 3);

            TextField grossSalaryField = new TextField();
            grid.add(grossSalaryField, 1, 3);

            Label netSalaryLabel = new Label("Net Salary::");
            grid.add(netSalaryLabel, 0, 4);

            TextField netSalaryField = new TextField();
            grid.add(netSalaryField, 1, 4);
            
            Button displayButton = new Button("Display");
            Button resetButton = new Button("Reset");
            Button deleteButton = new Button("Delete");
            Button quitBUtton = new Button("Quit");
            
            HBox hBoxDisplay = new HBox(displayButton, resetButton, deleteButton, quitBUtton);
            grid.add(hBoxDisplay, 1, 6);

            displayButton.setOnAction(actionEvent -> {
                    String employeeId = employeeIdField.getText().trim();                   
                    if (!BLANK.equals(employeeId)) {
                            try {                                   
                                    Employee empResult = EmpSql.getEmployee(employeeId);
                                    if (empResult != null) {
                                            employeeIdField.setText(Integer.toString(empResult.getEmployeeId())); 
                                            employeeNameField.setText(empResult.getEmployeeName());
                                            grossSalaryField.setText(Double.toString(empResult.getGrossSalary()));  
                                            netSalaryField.setText(Double.toString(empResult.getNetSalary())); 
                                    } else {
                                            this.alert("Error", "No employee with Id: "+employeeId+"!", AlertType.ERROR);
                                    }
                                    
                            } catch (Exception exception) {
                                    logger.log(Level.SEVERE, exception.getMessage());
                            }
                    } else {
                            this.alert("Error", "Enter Employee ID!", AlertType.ERROR);
                    }
            });
            
            resetButton.setOnAction(actionEvent -> {
                    employeeIdField.setText(BLANK);
                    employeeNameField.setText(BLANK);
                    grossSalaryField.setText(BLANK);
                    netSalaryField.setText(BLANK);
            });
            
            deleteButton.setOnAction(actionEvent -> {
                    String employeeId = employeeIdField.getText().trim();
                    if (!BLANK.equals(employeeId)) {
                            try {
                                    if (EmpSql.isUserExists(employeeId)) {
                                            boolean isDeleteSuccess = EmpSql.deleteEmployee(employeeId);
                                            if (isDeleteSuccess) {
                                                    this.alert("Delete", "Successful", AlertType.INFORMATION);
                                            } else {
                                                    this.alert("Error", "Failed", AlertType.ERROR);
                                            }
                                    } else {
                                            this.alert("Error", "User does not exist", AlertType.ERROR);
                                    }
                            } catch (Exception exception) {
                                    logger.log(Level.SEVERE, exception.getMessage());
                            }
                    } else {
                            this.alert("Error", "Enter Employee ID", AlertType.ERROR);
                    }
            });
            
            
            quitBUtton.setOnAction(actionEvent -> {
                    this.alert("Close", "Closing Window", AlertType.INFORMATION);
                    stage.close();
            });

            Scene scene = new Scene(grid, 500, 275);
            stage.setScene(scene);

            stage.show();
    }

    public void alert(String title, String message, AlertType alertType) {
            Alert alert = new Alert(alertType);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
    }

    public static void main(String[] args) {
            launch(args);
    }
}
