package application;

import java.io.Serializable;

public class Employee implements Serializable {

        private static final long serialVersionUID = 1L;
        private int employeeId;
        private String employeeName;
        private double grossSalary;
        private double netSalary;
        
        public Employee(int employeeId, String employeeName, double grossSalary, double netSalary) {
                super();
                this.employeeId = employeeId;
                this.employeeName = employeeName;
                this.grossSalary = grossSalary;
                this.netSalary = netSalary;
        }
        public Employee() {
                super();
        }
        public int getEmployeeId() {
                return employeeId;
        }
        public void setEmployeeId(int employeeId) {
                this.employeeId = employeeId;
        }
        public String getEmployeeName() {
                return employeeName;
        }
        public void setEmployeeName(String employeeName) {
                this.employeeName = employeeName;
        }
        public double getGrossSalary() {
                return grossSalary;
        }
        public void setGrossSalary(double grossSalary) {
                this.grossSalary = grossSalary;
        }
        public double getNetSalary() {
                return netSalary;
        }
        public void setNetSalary(double netSalary) {
                this.netSalary = netSalary;
        }

}
