package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmpSql {

        public Employee getEmployee(String employeeId) {
                Connection connection = null;
                PreparedStatement statement = null;
                Employee employee = null;
                try {
                        connection = DatabaseConnection.getDBConnection();
                        
                        String query = "SELECT EMPID, EMPNAME, EMPGRSAL FROM EMPOLOYEE WHERE EMPID = ?";
                        statement = connection.prepareStatement(query); 
                        statement.setInt(1, Integer.parseInt(employeeId));
                        ResultSet resultSet = statement.executeQuery();
                        
                        while (resultSet.next()) {
                                employee = new Employee();
                                employee.setEmployeeId(resultSet.getInt(1));
                                employee.setEmployeeName(resultSet.getString(2));
                                double grSal = resultSet.getDouble(3);
                                employee.setGrossSalary(grSal);
                                
                                double netSal = grSal - (grSal * 0.3);
                                employee.setNetSalary(netSal);                          
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                }
                return employee;
        }

        public boolean isUserExists(String employeeId) {
                Connection connection = null;
                PreparedStatement statement = null;
                boolean isEmployeeExists = false;
                try {
                        connection = DatabaseConnection.getDBConnection();
                        
                        String query = "SELECT * FROM EMPOLOYEE WHERE EMPID = ?";
                        statement = connection.prepareStatement(query); 
                        statement.setInt(1, Integer.parseInt(employeeId));
                        ResultSet resultSet = statement.executeQuery();
                        
                        while (resultSet.next()) {
                                isEmployeeExists = true;                        
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                }
                return isEmployeeExists;
        }

        public boolean deleteEmployee(String employeeId) {
                Connection connection = null;
                PreparedStatement statement = null;
                boolean isDeleteSuccess = false;
                try {
                        connection = DatabaseConnection.getDBConnection();
                        
                        String query = "DELETE FROM EMPOLOYEE WHERE EMPID = ?";
                        statement = connection.prepareStatement(query); 
                        statement.setInt(1, Integer.parseInt(employeeId));
                        int deleteCount = statement.executeUpdate();                    
                        if (deleteCount == 1) {
                                isDeleteSuccess = true;
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                }
                return isDeleteSuccess;
        }
}